import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TodoRoutingModule } from './todo-routing.module';
import { TodoContainerComponent } from './todo-container/todo-container.component';
import { EditTodoComponent } from './todo-container/edit-todo/edit-todo.component';
import { TodoListComponent } from './todo-container/todo-list/todo-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TodoServiceService } from './todo-container/todo-service.service';


@NgModule({
  declarations: [TodoContainerComponent, EditTodoComponent, TodoListComponent],
  imports: [
    CommonModule,
    TodoRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers:[TodoServiceService]
})
export class TodoModule { }
