import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TodoModel } from '../todo.model';

import { EditTodoComponent } from './edit-todo.component';

describe('EditTodoComponent', () => {
  let component: EditTodoComponent;
  let fixture: ComponentFixture<EditTodoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditTodoComponent ],
      imports: [FormsModule,
        ReactiveFormsModule],
        schemas:[CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTodoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should call addTask if isEditMode is false', () => {
      spyOn(component, 'addTask');
      component.ngOnInit();

      expect(component.addTask).toHaveBeenCalledWith();
    });

    it('should call editTaskDetails if isEditMode is true', () => {
      spyOn(component, 'editTaskDetails');
      component.task = new TodoModel();
      component.isEditMode = true;
      component.ngOnInit();

      expect(component.editTaskDetails).toHaveBeenCalledWith(component.task);
    });
  });

  describe('editPhase', () => {
    it('should set formDetails', () => {
      const accounts: TodoModel = new TodoModel();
      component.editTaskDetails(accounts);
      const formDetails = component.todoForm.value;

      fixture.detectChanges();

      expect(component.isUpdateRequest).toEqual(true);
      expect(formDetails.id).toEqual(accounts.id);
    })
  });

});
