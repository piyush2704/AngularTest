import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TodoModel } from '../todo.model';

@Component({
  selector: 'app-edit-todo',
  templateUrl: './edit-todo.component.html',
  styleUrls: ['./edit-todo.component.scss']
})
export class EditTodoComponent implements OnInit {

  @Input() isEditMode: boolean = false;
  @Input() task: any = {};
  @Output() formDetails: EventEmitter<any> = new EventEmitter();
  submitRequest: boolean = false;
  isUpdateRequest: boolean = false;
  todoForm: FormGroup;
  constructor(
    public fb: FormBuilder) {
    this.todoForm = this.generateForm()
  }

  public ngOnInit(): void {
    if (this.isEditMode) {
      this.editTaskDetails(this.task);
    } else {
      this.addTask();
    }
  }

  public editTaskDetails(todo: TodoModel): void {
    this.todoForm = this.fb.group({
      id: [todo.id],
      Description: [todo.Description, [Validators.required, Validators.maxLength(500)]],
      Category: [todo.Category, [Validators.required, Validators.maxLength(50)]],
      Status: [todo.Status],
      Name: [todo.Name, [Validators.required, Validators.maxLength(50)]]
    });
    this.isUpdateRequest = true;

  }


  public onSubmit() {
    this.submitRequest = true;
    if (this.todoForm.valid) {
      this.formDetails.emit(this.todoForm.value);
      this.submitRequest = false;
    }

  }
  public generateForm() {
    return this.fb.group({
      id: [], 
      Name: ['', [Validators.required, Validators.maxLength(50)]],
      Description: ['', [Validators.required, Validators.maxLength(500)] ],
      Category: [''],
      Status: ['Not Started']
    });
  }
  public addTask(): void {
    this.todoForm = this.generateForm()
    this.submitRequest = false;
    this.isUpdateRequest = false;
  }

  public resetCallback(): void {
    this.todoForm.reset();
    this.formDetails.emit(false);
  }
}
