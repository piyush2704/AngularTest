import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})

export class TodoServiceService {
  private pathRoot = 'http://localhost:3000';
  constructor(private http:HttpClient) { }

public getTask(): Observable<any> {
  return this.http.get(`${this.pathRoot}${'/tasks'}`);
}

public post(data: any): Observable<any> {
  return this.http.post(`${this.pathRoot}${'/tasks'}`, data);
}

public put(data: any): Observable<any> {
  return this.http.put(`${this.pathRoot}${'/tasks/'}${data.id}`, data);
}

public delete(data: any): Observable<any> {
  return this.http.delete(`${this.pathRoot}${'/tasks/'}${data.id}`);
}

}

