export class TodoModel {
  constructor() {}

  id: string = '';
  Name: string = '';
  Description: string = '';
  Category: string = '';
  Status: string = '';

}