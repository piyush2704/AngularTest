import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TodoServiceService } from './todo-service.service';
import { TodoModel } from './todo.model';

@Component({
  selector: 'app-todo-container',
  templateUrl: './todo-container.component.html',
  styleUrls: ['./todo-container.component.scss']
})
export class TodoContainerComponent implements OnInit {

  constructor(public todoServiceService: TodoServiceService) { }

  showEditForm: boolean = false;
  todoList: Observable<TodoModel[]> = new Observable();
  isEditMode: boolean = false;
  currentTodoItem: TodoModel;


  ngOnInit() {
    this.getTodoList();
  }

  public addTask(): void {
    this.showEditForm = true;
    this.isEditMode = false;
  }


  public editTaskDetails(formVal: TodoModel): void {
    this.showEditForm = true;
    this.currentTodoItem = formVal;
    this.isEditMode = true;
  }
  public getTodoList() {
    this.todoList = this.todoServiceService.getTask();
  }

  public markAsDone(formVal): void {
    formVal.Status = 'Done';

    this.todoServiceService.put(formVal).subscribe((data) => {
      this.getTodoList();
    });
  }


  public deleteTask(formVal): void {
    this.todoServiceService.delete(formVal).subscribe(() => {this.getTodoList()});
  }
  public sublitFormDetails(form): void {
    if (form !== false && !this.isEditMode) {
      this.todoServiceService.post(form).subscribe((data) => {
        this.getTodoList();
      });

    } else if (form !== false && this.isEditMode) {
      this.todoServiceService.put(form).subscribe((data) => {
        this.getTodoList();
      });
    }
    this.showEditForm = false;
  }
}
