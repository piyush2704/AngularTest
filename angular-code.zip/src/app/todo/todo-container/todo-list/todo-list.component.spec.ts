import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TodoModel } from '../todo.model';

import { TodoListComponent } from './todo-list.component';

describe('TodoListComponent', () => {
  let component: TodoListComponent;
  let fixture: ComponentFixture<TodoListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TodoListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('editTask', () => {
    it('should emit taskDetails', () => {
      spyOn(component.editTaskDetails, 'emit');
      component.editTask(new TodoModel());

      expect(component.editTaskDetails.emit).toHaveBeenCalledWith(new TodoModel());
    });
  });

  describe('deleteTask', () => {
    it('should emit deleteTaskDetails', () => {
      spyOn(component.deleteTaskDetails, 'emit');
      component.deleteTask(new TodoModel());

      expect(component.deleteTaskDetails.emit).toHaveBeenCalledWith(new TodoModel());
    });
  });

  describe('markDoneTask', () => {
    it('should emit markDoneTask', () => {
      spyOn(component.markAsDone, 'emit');
      component.markDoneTask(new TodoModel());

      expect(component.markAsDone.emit).toHaveBeenCalledWith(new TodoModel());
    });
  });
});
