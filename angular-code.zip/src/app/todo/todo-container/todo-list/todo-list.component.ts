import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';
import { TodoModel } from '../todo.model';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.scss']
})
export class TodoListComponent implements OnInit {
  @Input() todoList: any = [];
  @Output() editTaskDetails: EventEmitter<TodoModel> = new EventEmitter<TodoModel>();
  @Output() markAsDone: EventEmitter<TodoModel> = new EventEmitter<TodoModel>();
  @Output() deleteTaskDetails: EventEmitter<TodoModel> = new EventEmitter<TodoModel>();
  constructor() { }

  ngOnInit() {
  }

  editTask(data: TodoModel) {
    this.editTaskDetails.emit(data);
  }

  deleteTask(data: TodoModel) {
    this.deleteTaskDetails.emit(data);
  }

  markDoneTask(data: TodoModel) {
    this.markAsDone.emit(data);
  }
}
