import { HttpClient } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TodoContainerComponent } from './todo-container.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';

export class  HttpClientMock  {
  getTask() {
    return of({})
  }
  post() {
    return of({})
  }
  put() {
    return of({})
  }
  delete() {
    return of({})
  }
}

describe('TodoContainerComponent', () => {
  let component: TodoContainerComponent;
  let fixture: ComponentFixture<TodoContainerComponent>;
  let httpClient: HttpClient;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TodoContainerComponent ],
      imports:[HttpClientTestingModule],
      providers:[{provide: HttpClientMock , useClass: HttpClientMock}],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodoContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
